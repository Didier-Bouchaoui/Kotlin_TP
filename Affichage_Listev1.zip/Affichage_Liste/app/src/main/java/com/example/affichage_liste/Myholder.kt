package com.example.affichage_liste

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class Myholder(itemView: View) : RecyclerView.ViewHolder(itemView)