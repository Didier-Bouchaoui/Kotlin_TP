package com.example.affichage_liste.model


import com.google.gson.annotations.SerializedName

data class ChangeXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX(
    @SerializedName("active_cases")
    val activeCases: Int,
    @SerializedName("death_ratio")
    val deathRatio: Int,
    @SerializedName("deaths")
    val deaths: Int,
    @SerializedName("recovered")
    val recovered: Int,
    @SerializedName("recovery_ratio")
    val recoveryRatio: Double,
    @SerializedName("total_cases")
    val totalCases: Int
)